package com.example.matt.locationmarker;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements LocationListener {
    // Get Buttons
    Button mark;
    Button serach;

    // Get TextViews
    TextView current;
    TextView marked;
    TextView num;

    // Current Lat and long
    double currentLat;
    double currentLong;

    // Marked Lat and Long
    double markedLat;
    double markedLong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onLocationChanged(Location location) {
        currentLat = location.getLatitude();
        currentLong = location.getLongitude();

        current.setText("Current Location: lat: " + currentLat + " long: " + currentLong);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
