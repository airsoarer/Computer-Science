package com.example.matthew77402.locationmarker;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements LocationListener{

    // Get buttons
    Button search;
    Button mark;

    // Get TextViews
    TextView current;
    TextView marked;
    TextView numTxt;

    // Current Lat
    double currentLat;

    // Current Long
    double currentLong;

    // marked lat
    double markedLat;

    // Marked long
    double markedLong;

    // Number
    double num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set variables
        // Buttons
        search = (Button) findViewById(R.id.search);
        mark = (Button) findViewById(R.id.mark);

        // Textviews
        current = (TextView) findViewById(R.id.current);
        marked = (TextView) findViewById(R.id.marked);
        numTxt = (TextView) findViewById(R.id.number);

        LocationManager mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        mark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                markedLat = currentLat;
                markedLong = currentLong;

                marked.setText("Marked Location: lat: " + markedLat + " long: " + markedLong);
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public void onLocationChanged(Location location) {
        // Set current locales
        currentLat = location.getLatitude();
        currentLong = location.getLongitude();

        Log.d("LOCATION", Double.toString(currentLat));

        // Append to textview
        current.setText("Current Location: lat " + currentLat + " long: " + currentLong);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
